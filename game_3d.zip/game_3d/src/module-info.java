/**
 * 
 */
/**
 * 
 */
module game_3d {
	 requires java.desktop;
}